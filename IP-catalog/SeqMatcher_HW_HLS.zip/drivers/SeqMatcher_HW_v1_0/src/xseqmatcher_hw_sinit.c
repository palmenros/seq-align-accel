// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xseqmatcher_hw.h"

extern XSeqmatcher_hw_Config XSeqmatcher_hw_ConfigTable[];

XSeqmatcher_hw_Config *XSeqmatcher_hw_LookupConfig(u16 DeviceId) {
	XSeqmatcher_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSEQMATCHER_HW_NUM_INSTANCES; Index++) {
		if (XSeqmatcher_hw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XSeqmatcher_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XSeqmatcher_hw_Initialize(XSeqmatcher_hw *InstancePtr, u16 DeviceId) {
	XSeqmatcher_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XSeqmatcher_hw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XSeqmatcher_hw_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

