// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XSEQMATCHER_HW_H
#define XSEQMATCHER_HW_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xseqmatcher_hw_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XSeqmatcher_hw_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XSeqmatcher_hw;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XSeqmatcher_hw_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XSeqmatcher_hw_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XSeqmatcher_hw_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XSeqmatcher_hw_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XSeqmatcher_hw_Initialize(XSeqmatcher_hw *InstancePtr, u16 DeviceId);
XSeqmatcher_hw_Config* XSeqmatcher_hw_LookupConfig(u16 DeviceId);
int XSeqmatcher_hw_CfgInitialize(XSeqmatcher_hw *InstancePtr, XSeqmatcher_hw_Config *ConfigPtr);
#else
int XSeqmatcher_hw_Initialize(XSeqmatcher_hw *InstancePtr, const char* InstanceName);
int XSeqmatcher_hw_Release(XSeqmatcher_hw *InstancePtr);
#endif

void XSeqmatcher_hw_Start(XSeqmatcher_hw *InstancePtr);
u32 XSeqmatcher_hw_IsDone(XSeqmatcher_hw *InstancePtr);
u32 XSeqmatcher_hw_IsIdle(XSeqmatcher_hw *InstancePtr);
u32 XSeqmatcher_hw_IsReady(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_EnableAutoRestart(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_DisableAutoRestart(XSeqmatcher_hw *InstancePtr);
u32 XSeqmatcher_hw_Get_return(XSeqmatcher_hw *InstancePtr);

void XSeqmatcher_hw_Set_numDBEntries(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_numDBEntries(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_numSeqsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_numSeqsSpecimen(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_seqsDB(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_seqsDB(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_seqsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_seqsSpecimen(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_lengthsDB(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_lengthsDB(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_lengthsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_lengthsSpecimen(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_Set_scores_offset(XSeqmatcher_hw *InstancePtr, u32 Data);
u32 XSeqmatcher_hw_Get_scores_offset(XSeqmatcher_hw *InstancePtr);

void XSeqmatcher_hw_InterruptGlobalEnable(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_InterruptGlobalDisable(XSeqmatcher_hw *InstancePtr);
void XSeqmatcher_hw_InterruptEnable(XSeqmatcher_hw *InstancePtr, u32 Mask);
void XSeqmatcher_hw_InterruptDisable(XSeqmatcher_hw *InstancePtr, u32 Mask);
void XSeqmatcher_hw_InterruptClear(XSeqmatcher_hw *InstancePtr, u32 Mask);
u32 XSeqmatcher_hw_InterruptGetEnabled(XSeqmatcher_hw *InstancePtr);
u32 XSeqmatcher_hw_InterruptGetStatus(XSeqmatcher_hw *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
