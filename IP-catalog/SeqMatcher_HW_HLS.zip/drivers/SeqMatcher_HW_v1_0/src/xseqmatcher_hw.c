// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xseqmatcher_hw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XSeqmatcher_hw_CfgInitialize(XSeqmatcher_hw *InstancePtr, XSeqmatcher_hw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XSeqmatcher_hw_Start(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XSeqmatcher_hw_IsDone(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XSeqmatcher_hw_IsIdle(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XSeqmatcher_hw_IsReady(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XSeqmatcher_hw_EnableAutoRestart(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XSeqmatcher_hw_DisableAutoRestart(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XSeqmatcher_hw_Get_return(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XSeqmatcher_hw_Set_numDBEntries(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_NUMDBENTRIES_DATA, Data);
}

u32 XSeqmatcher_hw_Get_numDBEntries(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_NUMDBENTRIES_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_numSeqsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_NUMSEQSSPECIMEN_DATA, Data);
}

u32 XSeqmatcher_hw_Get_numSeqsSpecimen(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_NUMSEQSSPECIMEN_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_seqsDB(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SEQSDB_DATA, Data);
}

u32 XSeqmatcher_hw_Get_seqsDB(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SEQSDB_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_seqsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SEQSSPECIMEN_DATA, Data);
}

u32 XSeqmatcher_hw_Get_seqsSpecimen(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SEQSSPECIMEN_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_lengthsDB(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_LENGTHSDB_DATA, Data);
}

u32 XSeqmatcher_hw_Get_lengthsDB(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_LENGTHSDB_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_lengthsSpecimen(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_LENGTHSSPECIMEN_DATA, Data);
}

u32 XSeqmatcher_hw_Get_lengthsSpecimen(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_LENGTHSSPECIMEN_DATA);
    return Data;
}

void XSeqmatcher_hw_Set_scores_offset(XSeqmatcher_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SCORES_OFFSET_DATA, Data);
}

u32 XSeqmatcher_hw_Get_scores_offset(XSeqmatcher_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_SCORES_OFFSET_DATA);
    return Data;
}

void XSeqmatcher_hw_InterruptGlobalEnable(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_GIE, 1);
}

void XSeqmatcher_hw_InterruptGlobalDisable(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_GIE, 0);
}

void XSeqmatcher_hw_InterruptEnable(XSeqmatcher_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_IER);
    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_IER, Register | Mask);
}

void XSeqmatcher_hw_InterruptDisable(XSeqmatcher_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_IER);
    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XSeqmatcher_hw_InterruptClear(XSeqmatcher_hw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XSeqmatcher_hw_WriteReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_ISR, Mask);
}

u32 XSeqmatcher_hw_InterruptGetEnabled(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_IER);
}

u32 XSeqmatcher_hw_InterruptGetStatus(XSeqmatcher_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XSeqmatcher_hw_ReadReg(InstancePtr->Control_BaseAddress, XSEQMATCHER_HW_CONTROL_ADDR_ISR);
}

